import React from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import {
  Calendar,
  FileText,
  Home,
  Users,
  Video,
  Activity,
  ClipboardList,
} from 'lucide-react';

export function Sidebar() {
  const { user } = useAuthStore();

  const doctorLinks = [
    { to: '/dashboard', icon: Home, label: 'Dashboard' },
    { to: '/patients', icon: Users, label: 'Patients' },
    { to: '/appointments', icon: Calendar, label: 'Appointments' },
    { to: '/records', icon: FileText, label: 'Medical Records' },
    { to: '/consultations', icon: Video, label: 'Video Consultations' },
  ];

  const patientLinks = [
    { to: '/dashboard', icon: Home, label: 'Dashboard' },
    { to: '/appointments', icon: Calendar, label: 'Appointments' },
    { to: '/history', icon: FileText, label: 'Medical History' },
    { to: '/metrics', icon: Activity, label: 'Health Metrics' },
    { to: '/prescriptions', icon: ClipboardList, label: 'Prescriptions' },
  ];

  const links = user?.role === 'doctor' ? doctorLinks : patientLinks;

  return (
    <div className="h-full w-64 bg-gray-50 border-r border-gray-200">
      <nav className="mt-5 px-2">
        <div className="space-y-1">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100"
            >
              <link.icon className="mr-3 h-5 w-5 text-gray-500" />
              {link.label}
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}