import React from 'react';
import { useAuthStore } from '../store/authStore';
import { FileText, Download, Plus } from 'lucide-react';
import { formatDate } from '../lib/utils';

export function MedicalRecords() {
  const { user } = useAuthStore();

  const records = [
    {
      id: '1',
      date: new Date('2024-02-15'),
      title: 'Annual Check-up',
      doctor: 'Dr. John Doe',
      diagnosis: 'Healthy, no concerns',
      hasAttachments: true,
    },
    {
      id: '2',
      date: new Date('2024-01-20'),
      title: 'Follow-up Consultation',
      doctor: 'Dr. Sarah Wilson',
      diagnosis: 'Recovery progressing well',
      hasAttachments: true,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Medical Records</h1>
        {user?.role === 'doctor' && (
          <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            New Record
          </button>
        )}
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <ul className="divide-y divide-gray-200">
          {records.map((record) => (
            <li key={record.id}>
              <div className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center">
                      <FileText className="h-5 w-5 text-gray-400" />
                      <p className="ml-2 text-sm font-medium text-gray-900">
                        {record.title}
                      </p>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm text-gray-500">
                        Doctor: {record.doctor}
                      </p>
                      <p className="mt-1 text-sm text-gray-500">
                        Date: {formatDate(record.date)}
                      </p>
                      <p className="mt-1 text-sm text-gray-500">
                        Diagnosis: {record.diagnosis}
                      </p>
                    </div>
                  </div>
                  {record.hasAttachments && (
                    <button className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}