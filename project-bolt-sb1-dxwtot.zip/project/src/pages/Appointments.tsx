import React from 'react';
import { useAuthStore } from '../store/authStore';
import { Calendar, Clock, Video, User } from 'lucide-react';
import { formatDate } from '../lib/utils';

export function Appointments() {
  const { user } = useAuthStore();

  const appointments = [
    {
      id: '1',
      date: new Date('2024-03-20T10:00:00'),
      type: 'in-person',
      with: user?.role === 'doctor' ? 'Jane Smith' : 'Dr. John Doe',
      status: 'scheduled',
    },
    {
      id: '2',
      date: new Date('2024-03-22T14:30:00'),
      type: 'video',
      with: user?.role === 'doctor' ? 'John Brown' : 'Dr. Sarah Wilson',
      status: 'scheduled',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Appointments</h1>
        <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
          <Calendar className="h-4 w-4 mr-2" />
          New Appointment
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {appointments.map((appointment) => (
            <li key={appointment.id}>
              <div className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      {appointment.type === 'video' ? (
                        <Video className="h-6 w-6 text-blue-500" />
                      ) : (
                        <User className="h-6 w-6 text-green-500" />
                      )}
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-900">
                        Appointment with {appointment.with}
                      </p>
                      <div className="flex items-center mt-1">
                        <Calendar className="h-4 w-4 text-gray-400 mr-1" />
                        <p className="text-sm text-gray-500">
                          {formatDate(appointment.date)}
                        </p>
                        <Clock className="h-4 w-4 text-gray-400 ml-4 mr-1" />
                        <p className="text-sm text-gray-500">
                          {appointment.date.toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      {appointment.status}
                    </span>
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}