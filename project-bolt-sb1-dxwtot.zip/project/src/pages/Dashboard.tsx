import React from 'react';
import { useAuthStore } from '../store/authStore';
import { Calendar, Users, Activity, FileText } from 'lucide-react';

export function Dashboard() {
  const { user } = useAuthStore();

  const stats = user?.role === 'doctor' ? [
    { name: 'Total Patients', value: '150+', icon: Users },
    { name: 'Appointments Today', value: '8', icon: Calendar },
    { name: 'Pending Reports', value: '3', icon: FileText },
    { name: 'Success Rate', value: '98%', icon: Activity },
  ] : [
    { name: 'Upcoming Appointments', value: '2', icon: Calendar },
    { name: 'Prescriptions', value: '3', icon: FileText },
    { name: 'Health Score', value: '85%', icon: Activity },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">
        Welcome back, {user?.name}
      </h1>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.name}
            className="bg-white overflow-hidden shadow rounded-lg"
          >
            <div className="p-5">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <stat.icon className="h-6 w-6 text-gray-400" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">
                      {stat.name}
                    </dt>
                    <dd className="text-lg font-semibold text-gray-900">
                      {stat.value}
                    </dd>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Recent Activity
          </h3>
          {/* Activity list would go here */}
        </div>
      </div>
    </div>
  );
}