export interface User {
  id: string;
  name: string;
  email: string;
  role: 'doctor' | 'patient';
  specialization?: string;
  profileImage?: string;
}

export interface Appointment {
  id: string;
  doctorId: string;
  patientId: string;
  date: Date;
  status: 'scheduled' | 'completed' | 'cancelled';
  type: 'in-person' | 'video';
  notes?: string;
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  doctorId: string;
  date: Date;
  diagnosis: string;
  prescription?: string;
  notes?: string;
  attachments?: string[];
}